import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class circleArt extends PApplet {

String shapeName = "circle";
float redc = 102;
float greenc = 102;
float bluec = 102;

public void setup()
{
  size(screen.width, screen.height);
  background(102);
  smooth();
}


public void draw() 
{
  // Call the variableEllipse() method and send it the
  // parameters for the current mouse position
  // and the previous mouse position
  variableEllipse(mouseX, mouseY, pmouseX, pmouseY);
}


// The simple method variableEllipse() was created specifically 
// for this program. It calculates the speed of the mouse
// and draws a small ellipse if the mouse is moving slowly
// and draws a large ellipse if the mouse is moving quickly 

public void variableEllipse(int x, int y, int px, int py) 
{
  float speed = abs(x-px) + abs(y-py);
  stroke(speed);
  fill(redc, greenc, bluec);
  if (mousePressed == true ) {    
    changeColour();
  }
      drawShape(x, y, speed, speed);

}

public void toggleShape(int x, int y, float speedx, float speedy){
if (shapeName == "circle"){
      rect(x, y, speedx, speedy);
      shapeName = "rectangle";
} else {
    ellipse(x, y, speedx, speedy);
    shapeName = "circle";
}
}

public void drawShape(int x, int y, float speedx, float speedy){
if (shapeName == "circle"){
      ellipse(x, y, speedx, speedy);
} else {
    rect(x, y, speedx, speedy);
}
}

public void changeColour(){
  redc = random(0, 255);
  greenc = random(0, 255);
  bluec = random(0, 255);
}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--present", "--bgcolor=#666666", "--stop-color=#cccccc", "circleArt" });
  }
}
